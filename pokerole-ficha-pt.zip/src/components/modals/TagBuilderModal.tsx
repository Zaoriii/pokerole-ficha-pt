import { useState } from 'react';
import { useCharacterStore } from '../../store/useCharacterStore';
import { CombatStat, SocialStat, Skill } from '../../types/enums';
import { POKEMON_TYPES } from '../../data/constants';
import './TagBuilderModal.css';

interface TagBuilderModalProps {
    targetId: string;
    targetType:
        | 'item'
        | 'move'
        | 'homebrew_ability'
        | 'homebrew_move'
        | 'homebrew_item'
        | 'homebrew_form'
        | 'homebrew_status';
    onClose: () => void;
}

export function TagBuilderModal({ targetId, targetType, onClose }: TagBuilderModalProps) {
    const updateInventoryItem = useCharacterStore((state) => state.updateInventoryItem);
    const updateMove = useCharacterStore((state) => state.updateMove);
    const updateCustomAbility = useCharacterStore((state) => state.updateCustomAbility);
    const updateCustomMove = useCharacterStore((state) => state.updateCustomMove);
    const updateCustomItem = useCharacterStore((state) => state.updateCustomItem);
    const updateCustomForm = useCharacterStore((state) => state.updateCustomForm);
    const updateCustomStatus = useCharacterStore((state) => state.updateCustomStatus);

    const inventory = useCharacterStore((state) => state.inventory);
    const moves = useCharacterStore((state) => state.moves);
    const customAbilities = useCharacterStore((state) => state.roomCustomAbilities);
    const customMoves = useCharacterStore((state) => state.roomCustomMoves);
    const customItems = useCharacterStore((state) => state.roomCustomItems);
    const customForms = useCharacterStore((state) => state.roomCustomForms);
    const customStatuses = useCharacterStore((state) => state.roomCustomStatuses);

    const roomCustomTypes = useCharacterStore((state) => state.roomCustomTypes);
    const extraCategories = useCharacterStore((state) => state.extraCategories);

    const [category, setCategory] = useState('stat');
    const [target, setTarget] = useState('Str');
    const [typeOption, setTypeOption] = useState('');
    const [value, setValue] = useState<number>(1);
    const [value2, setValue2] = useState<number>(6); // Specifically used for the limit variable

    const formatEnum = (str: string) => str.charAt(0).toUpperCase() + str.slice(1);

    const dynamicTypeOptions = [
        ...POKEMON_TYPES.filter((t) => t !== ''),
        ...roomCustomTypes.map((t) => t.name),
        'Physical',
        'Special',
        'Super Effective'
    ];

    const getTargetOptions = () => {
        if (category === 'stat') {
            return [
                ...Object.values(CombatStat).map(formatEnum),
                ...Object.values(SocialStat).map(formatEnum),
                'Def',
                'Spd'
            ];
        }
        if (category === 'skill') {
            const customSkillNames = extraCategories.flatMap((c) => c.skills.map((s) => s.name || 'Unnamed'));
            return [...Object.values(Skill).map(formatEnum), ...customSkillNames];
        }
        if (category === 'combat')
            return ['Dmg', 'Acc', 'Init', 'Chance', 'Combo Dmg', 'First Hit Dmg', 'First Hit Acc'];
        if (category === 'matchup') return ['Immune', 'Resist', 'Weak', 'Remove Immunities', 'Remove Immunity'];

        if (category === 'mechanic')
            return [
                'High Crit',
                'Stacking High Crit',
                'Ignore Low Acc',
                'Recoil',
                'Super Effective',
                'Powder',
                'Gain Temp HP',
                'Temp HP on Hit',
                'Temp HP % Dmg',
                'Acc [X]s Add Dmg Limit [Y]'
            ];

        if (category === 'turn_based')
            return [
                'Deal Damage End of Round',
                'Reduce Will End of Round',
                'Heal Round End',
                'Restore Will Round End',
                'Lose Action(s)',
                'No Reactions',
                'Extra Reaction(s)'
            ];

        if (category === 'status')
            return [
                '1st Degree Burn',
                '2nd Degree Burn',
                '3rd Degree Burn',
                'Poison',
                'Badly Poisoned',
                'Paralysis',
                'Sleep',
                'Frozen Solid',
                'Confusion',
                'In Love',
                'Flinch'
            ];
        if (category === 'move_mechanics')
            return [
                'High Critical',
                'Low Accuracy',
                'Never Miss',
                'Recoil',
                'Successive Actions',
                'Set Damage',
                'Powder'
            ];
        return [];
    };

    const showTypeSelect =
        (category === 'combat' &&
            !['Init', 'Chance', 'Combo Dmg', 'First Hit Dmg', 'First Hit Acc'].includes(target)) ||
        (category === 'matchup' && target !== 'Remove Immunities');

    const showValueInput =
        category === 'stat' ||
        category === 'skill' ||
        category === 'combat' ||
        (category === 'mechanic' &&
            [
                'Ignore Low Acc',
                'Gain Temp HP',
                'Temp HP on Hit',
                'Temp HP % Dmg',
                'Acc [X]s Add Dmg Limit [Y]'
            ].includes(target)) ||
        (category === 'turn_based' && target !== 'No Reactions') ||
        (category === 'move_mechanics' && ['Low Accuracy', 'Set Damage'].includes(target));

    const handleConfirm = () => {
        let tag = '';

        const numValue = Number(value) || 0;
        const numValue2 = Number(value2) || 0;
        const sign = numValue >= 0 ? `+${numValue}` : `${numValue}`;

        if (category === 'stat' || category === 'skill') {
            tag = `[${target} ${sign}]`;
        } else if (category === 'combat') {
            if (['Init', 'Chance', 'Combo Dmg', 'First Hit Dmg', 'First Hit Acc'].includes(target))
                tag = `[${target} ${sign}]`;
            else if (typeOption) tag = `[${target} ${sign}: ${typeOption}]`;
            else tag = `[${target} ${sign}]`;
        } else if (category === 'matchup') {
            if (target === 'Remove Immunities') tag = `[Remove Immunities]`;
            else if (typeOption) tag = `[${target}: ${typeOption}]`;
            else {
                alert('É necessário selecionar um tipo para a efetividade!');
                return;
            }
        } else if (category === 'mechanic') {
            if (target === 'High Crit') tag = `[High Crit]`;
            else if (target === 'Stacking High Crit') tag = `[Stacking High Crit]`;
            else if (target === 'Ignore Low Acc') tag = `[Ignore Low Acc ${Math.abs(numValue)}]`;
            else if (target === 'Recoil') tag = `[Recoil]`;
            else if (target === 'Super Effective') tag = `[Super Effective]`;
            else if (target === 'Powder') tag = `[Powder]`;
            else if (target === 'Gain Temp HP') tag = `[Gain Temp HP ${Math.abs(numValue)}]`;
            else if (target === 'Temp HP on Hit') tag = `[Temp HP +${Math.abs(numValue)} on Hit]`;
            else if (target === 'Temp HP % Dmg') tag = `[Temp HP ${Math.abs(numValue)}% Dmg]`;
            else if (target === 'Acc [X]s Add Dmg Limit [Y]')
                tag = `[Acc ${Math.abs(numValue)}s Add Dmg Limit ${Math.abs(numValue2)}]`;
        } else if (category === 'turn_based') {
            if (target === 'Deal Damage End of Round') tag = `[Deal ${Math.abs(numValue)} Damage at End of Round]`;
            else if (target === 'Reduce Will End of Round')
                tag = `[Reduce Will by ${Math.abs(numValue)} at End of Round]`;
            else if (target === 'Heal Round End') tag = `[Heal ${Math.abs(numValue)} Round End]`;
            else if (target === 'Restore Will Round End') tag = `[Restore ${Math.abs(numValue)} Will Round End]`;
            else if (target === 'Lose Action(s)') tag = `[Lose ${Math.abs(numValue)} Action]`;
            else if (target === 'No Reactions') tag = `[No Reactions]`;
            else if (target === 'Extra Reaction(s)') tag = `[${Math.abs(numValue)} Extra Reactions Per Turn]`;
        } else if (category === 'status') {
            tag = `[Status: ${target}]`;
        } else if (category === 'move_mechanics') {
            if (target === 'High Critical') tag = `[High Critical]`;
            else if (target === 'Low Accuracy') tag = `[Low Accuracy ${Math.abs(numValue)}]`;
            else if (target === 'Never Miss') tag = `[Never Miss]`;
            else if (target === 'Recoil') tag = `[Recoil]`;
            else if (target === 'Successive Actions') tag = `[Successive Actions]`;
            else if (target === 'Set Damage') tag = `[Set Damage ${Math.abs(numValue)}]`;
            else if (target === 'Powder') tag = `[Powder]`;
        }

        if (tag) {
            if (targetType === 'move') {
                const move = moves.find((m) => m.id === targetId);
                if (move) updateMove(targetId, 'desc', move.desc ? `${move.desc} ${tag}`.trim() : tag);
            } else if (targetType === 'homebrew_move') {
                const hbMove = customMoves.find((m) => m.id === targetId);
                if (hbMove) updateCustomMove(targetId, 'desc', hbMove.desc ? `${hbMove.desc} ${tag}`.trim() : tag);
            } else if (targetType === 'homebrew_ability') {
                const hbAbility = customAbilities.find((a) => a.id === targetId);
                if (hbAbility)
                    updateCustomAbility(
                        targetId,
                        'effect',
                        hbAbility.effect ? `${hbAbility.effect} ${tag}`.trim() : tag
                    );
            } else if (targetType === 'homebrew_item') {
                const hbItem = customItems.find((i) => i.id === targetId);
                if (hbItem)
                    updateCustomItem(
                        targetId,
                        'description',
                        hbItem.description ? `${hbItem.description} ${tag}`.trim() : tag
                    );
            } else if (targetType === 'homebrew_form') {
                const hbForm = customForms.find((f) => f.id === targetId);
                if (hbForm) updateCustomForm(targetId, 'tags', hbForm.tags ? `${hbForm.tags} ${tag}`.trim() : tag);
            } else if (targetType === 'homebrew_status') {
                const hbStatus = customStatuses.find((s) => s.id === targetId);
                if (hbStatus)
                    updateCustomStatus(
                        targetId,
                        'effects',
                        hbStatus.effects ? `${hbStatus.effects} ${tag}`.trim() : tag
                    );
            } else {
                const item = inventory.find((i) => i.id === targetId);
                if (item) updateInventoryItem(targetId, 'desc', item.desc ? `${item.desc} ${tag}`.trim() : tag);
            }
        }
        onClose();
    };

    return (
        <div className="tag-builder__overlay">
            <div className="tag-builder__content">
                <h3 className="tag-builder__title">🏷️ Construtor de Tags</h3>

                <div className="tag-builder__form-group">
                    <select
                        className="identity-grid__select tag-builder__select"
                        value={category}
                        onChange={(e) => {
                            setCategory(e.target.value);
                            setTarget('');
                        }}
                    >
                        <option value="stat">Modificador de Atributo</option>
                        <option value="skill">Modificador de Perícia</option>
                        <option value="combat">Bônus de Combate</option>
                        <option value="matchup">Efetividade</option>
                        <option value="mechanic">Mecânica</option>
                        <option value="turn_based">Baseado em Turno / Ações</option>
                        <option value="status">Condição de Status</option>
                        {targetType === 'move' && <option value="move_mechanics">Mecânica de Golpe</option>}
                    </select>

                    <select
                        className="identity-grid__select tag-builder__select"
                        value={target}
                        onChange={(e) => setTarget(e.target.value)}
                    >
                        <option value="">-- Selecionar --</option>
                        {getTargetOptions().map((o) => (
                            <option key={o} value={o}>
                                {o}
                            </option>
                        ))}
                    </select>

                    {showTypeSelect && (
                        <select
                            className="identity-grid__select tag-builder__select"
                            value={typeOption}
                            onChange={(e) => setTypeOption(e.target.value)}
                        >
                            <option value="">-- Qualquer Tipo --</option>
                            {dynamicTypeOptions.map((t) => (
                                <option key={t} value={t}>
                                    {t}
                                </option>
                            ))}
                        </select>
                    )}

                    {showValueInput && (
                        <div className="tag-builder__value-row">
                            <span className="tag-builder__value-label">Valor:</span>
                            <input
                                type="number"
                                className="identity-grid__input tag-builder__value-input"
                                value={value}
                                onChange={(e) => setValue(Number(e.target.value) || 0)}
                            />
                            {target === 'Acc [X]s Add Dmg Limit [Y]' && (
                                <>
                                    <span className="tag-builder__value-label" style={{ marginLeft: '10px' }}>
                                        Limite:
                                    </span>
                                    <input
                                        type="number"
                                        className="identity-grid__input tag-builder__value-input"
                                        value={value2}
                                        onChange={(e) => setValue2(Number(e.target.value) || 0)}
                                    />
                                </>
                            )}
                        </div>
                    )}
                </div>

                <div className="tag-builder__actions">
                    <button className="action-button action-button--dark tag-builder__btn-cancel" onClick={onClose}>
                        Cancelar
                    </button>
                    <button className="action-button tag-builder__btn-confirm" onClick={handleConfirm}>
                        🏷️ Adicionar Tag
                    </button>
                </div>
            </div>
        </div>
    );
}
