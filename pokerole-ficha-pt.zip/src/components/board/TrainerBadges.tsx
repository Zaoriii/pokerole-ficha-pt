import { useState } from 'react';
import { useCharacterStore } from '../../store/useCharacterStore';
import { CollapsingSection } from '../ui/CollapsingSection';
import { TrainerBadgeRow } from './TrainerBadgeRow';
import './TrainerBadges.css';

export function TrainerBadges() {
    const badges = useCharacterStore((state) => state.identity.badges) || [];
    const setIdentity = useCharacterStore((state) => state.setIdentity);

    const [deleteBadgeId, setDeleteBadgeId] = useState<string | null>(null);

    const addBadge = () => {
        setIdentity('badges', [...badges, { id: crypto.randomUUID(), name: '', emoji: '🏅' }]);
    };

    const removeBadge = (id: string) => {
        setIdentity(
            'badges',
            badges.filter((b) => b.id !== id)
        );
    };

    const updateBadge = (id: string, field: 'name' | 'emoji', value: string) => {
        setIdentity(
            'badges',
            badges.map((b) => (b.id === id ? { ...b, [field]: value } : b))
        );
    };

    const headerElements = <div className="trainer-badges__count">Total: {badges.length}</div>;

    return (
        <CollapsingSection title="INSÍGNIAS E CONQUISTAS" headerElements={headerElements} className="sheet-panel">
            <div className="trainer-badges__list">
                {badges.length === 0 ? (
                    <div className="trainer-badges__empty">Nenhuma insígnia coletada ainda.</div>
                ) : (
                    badges.map((badge) => (
                        <TrainerBadgeRow
                            key={badge.id}
                            badge={badge}
                            onUpdate={(field, value) => updateBadge(badge.id, field, value)}
                            onRemove={() => setDeleteBadgeId(badge.id)}
                        />
                    ))
                )}
            </div>
            <button
                type="button"
                onClick={addBadge}
                className="action-button action-button--dark trainer-badges__add-btn"
            >
                + Adicionar Insígnia
            </button>

            {deleteBadgeId && (
                <div className="trainer-badges__modal-overlay">
                    <div className="trainer-badges__modal-content">
                        <h3 className="trainer-badges__modal-title">⚠️ Confirmar Exclusão</h3>
                        <p className="trainer-badges__modal-text">Tem certeza de que deseja excluir esta Insígnia?</p>
                        <div className="trainer-badges__modal-actions">
                            <button
                                type="button"
                                className="action-button action-button--dark trainer-badges__modal-btn"
                                onClick={() => setDeleteBadgeId(null)}
                            >
                                Cancelar
                            </button>
                            <button
                                type="button"
                                className="action-button action-button--red trainer-badges__modal-btn"
                                onClick={() => {
                                    removeBadge(deleteBadgeId);
                                    setDeleteBadgeId(null);
                                }}
                            >
                                Excluir
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </CollapsingSection>
    );
}
